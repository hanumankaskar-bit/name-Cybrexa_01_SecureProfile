# SecureProfile — Personal Portfolio Website

![Beginner](https://img.shields.io/badge/level-beginner-22d3ee?style=flat-square)
![5–7 Days](https://img.shields.io/badge/duration-5--7%20days-22d3ee?style=flat-square)
![Security Reviewed](https://img.shields.io/badge/security-reviewed-34d399?style=flat-square)

A five-page personal portfolio built with plain **HTML, CSS, and JavaScript**,
made for Cybrexa Technologies' beginner project track. It doubles as an
applied first project for a cybersecurity learning path: secure coding
practices (input validation, XSS-aware forms) are treated as a real
requirement, not decoration. See **[SECURITY.md](./SECURITY.md)** for details.

**Stack:** HTML · CSS · JS · Git

## Pages

| Page | Purpose |
|---|---|
| `index.html` | Home — hero section, professional headline, CTA buttons |
| `about.html` | Education history + 5-phase cybersecurity skills roadmap |
| `skills.html` | Skill progress bars + a learning-path timeline |
| `contact.html` | Contact form with client-side validation, GitHub & LinkedIn links |
| `SECURITY.md` | Security policy, XSS prevention notes, vulnerability reporting |

## Repo structure

```
Cybrexa_01_SecureProfile/
├── index.html
├── about.html
├── skills.html
├── contact.html
├── style.css
├── script.js
├── images/
│   └── (screenshots go here)
├── README.md
└── SECURITY.md
```

## Before you publish — replace the placeholders

Search each HTML file for bracketed placeholders and swap in your real info:

- `[Your Name]` — appears in every page `<title>`, hero, and meta description
- `[University Name]`, `[Platform / Institution]`, `[School Name]` — `about.html`
- Skill percentages in `skills.html` — set them honestly
- `https://github.com/` and `https://linkedin.com/` links — `index.html` and `contact.html`
- `you@example.com` — `contact.html` and `SECURITY.md`
- `YOUR_USERNAME` in the SECURITY.md link inside `index.html` / `contact.html`

## Run it locally

No build step — it's static HTML. Either:

- Open `index.html` directly in a browser, or
- Serve it locally for a closer-to-production feel:
  ```bash
  npx serve .
  # or
  python3 -m http.server 8000
  ```

## Deploy

**Netlify (drag-and-drop):**
1. Go to [app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag the whole project folder in
3. Copy the generated live URL

**GitHub Pages:**
1. Push this repo to GitHub as `Cybrexa_01_SecureProfile`
2. Settings → Pages → Source: `main` branch, `/ (root)`
3. Your live URL: `https://YOUR_USERNAME.github.io/Cybrexa_01_SecureProfile/`

## Deliverables checklist

- [ ] GitHub repo: `Cybrexa_01_SecureProfile`
- [ ] Live URL (Netlify or GitHub Pages)
- [ ] 4+ screenshots (desktop + mobile) in `/images`
- [ ] 2–3 min screen-recording demo for a LinkedIn post
- [ ] LinkedIn post mentioning **Cybrexa** with the GitHub link

## License

Personal portfolio template — free to adapt for your own use.
