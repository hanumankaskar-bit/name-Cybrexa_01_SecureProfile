Drop your 4+ screenshots here (desktop + mobile), e.g.:
- home-desktop.png
- home-mobile.png
- about-desktop.png
- skills-desktop.png
- contact-desktop.png

Git won't track an empty folder, so this file (or your first screenshot) keeps it in the repo.
