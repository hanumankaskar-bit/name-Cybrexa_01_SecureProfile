# Security Policy

![Security: Reviewed](https://img.shields.io/badge/security-reviewed-34d399?style=flat-square)
![XSS: Mitigated](https://img.shields.io/badge/XSS-mitigated-22d3ee?style=flat-square)

This document describes the security posture of the SecureProfile portfolio site
and how to report an issue if you find one.

## Scope

SecureProfile is a static site (HTML/CSS/vanilla JS) with one client-side form
(`contact.html`). There is no server, database, or authentication in this build.

## XSS Prevention

Cross-site scripting is the main realistic risk on a static site with a form, so:

- **No `innerHTML` with user input.** `script.js` never writes form values into the
  DOM using `innerHTML`. All validation messages are static strings the developer
  wrote, not user-controlled content.
- **`sanitize()` helper.** Before the contact form payload is logged or (later)
  sent to a backend, `script.js` runs values through a `textContent`-based
  sanitizer (`sanitize()` in `script.js`) that neutralizes any HTML the user typed,
  so a name like `<script>alert(1)</script>` is stored as inert text, not markup.
- **No `eval`, no `document.write`.** The codebase avoids both.
- **Form has no backend yet.** `contact.html` validates and sanitizes on the
  client but does not transmit data anywhere. Before wiring up a real backend:
  - Re-validate and sanitize server-side too — client-side checks are a UX
    convenience, never a security boundary.
  - Use a provider (Formspree, Netlify Forms) or your own API with server-side
    input validation and rate limiting.
  - Add a honeypot field or CAPTCHA if spam becomes a problem.
- **External links use `rel="noopener"`.** Every `target="_blank"` link
  (GitHub, LinkedIn) includes `rel="noopener"` to prevent `window.opener`
  tab-napping attacks.

## Content Security

- No inline `<script>` blocks with dynamic content; all JS lives in `script.js`.
- No third-party scripts beyond Google Fonts (CSS only, no JS payload).
- If you add analytics or embeds later, add a `Content-Security-Policy` meta tag
  or HTTP header restricting allowed script/style sources.

## Reporting a Vulnerability

If you find a security issue in this project, please open a private report:

1. Do **not** open a public GitHub issue for security bugs.
2. Email **you@example.com** with a description and steps to reproduce.
3. You'll get an acknowledgement within a few days.

## Checklist (update as the project grows)

- [x] No use of `innerHTML` with unsanitized user input
- [x] Contact form validates required fields and email format
- [x] `rel="noopener"` on all external links
- [x] No secrets or API keys committed to the repository
- [ ] Server-side validation added once a real backend is connected
- [ ] HTTPS enforced on the deployed URL (handled automatically by Netlify / GitHub Pages)
