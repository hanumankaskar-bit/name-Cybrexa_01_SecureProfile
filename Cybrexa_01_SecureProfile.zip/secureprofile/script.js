// ============================================================
// SecureProfile — shared behavior
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  initNavToggle();
  initScrollReveal();
  initSkillBars();
  initContactForm();
});

/* ---------- Mobile nav toggle ---------- */
function initNavToggle() {
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (!toggle || !links) return;
  toggle.addEventListener('click', () => {
    const isOpen = links.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(isOpen));
    toggle.textContent = isOpen ? 'CLOSE' : 'MENU';
  });
}

/* ---------- Scroll-triggered reveal ---------- */
function initScrollReveal() {
  const items = document.querySelectorAll('.reveal');
  if (!items.length) return;

  if (!('IntersectionObserver' in window)) {
    items.forEach(el => el.classList.add('visible'));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  items.forEach(el => observer.observe(el));
}

/* ---------- Animate skill progress bars once visible ---------- */
function initSkillBars() {
  const bars = document.querySelectorAll('.bar-fill');
  if (!bars.length) return;

  if (!('IntersectionObserver' in window)) {
    bars.forEach(el => el.classList.add('filled'));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('filled');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  bars.forEach(el => observer.observe(el));
}

/* ---------- Contact form validation ----------
   Client-side only. No data leaves the browser in this template —
   wire up a real endpoint (Formspree, Netlify Forms, your own API)
   before relying on this in production. See SECURITY.md. */
function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;

  const status = document.getElementById('form-status');

  const validators = {
    name: (v) => v.trim().length >= 2 || 'Enter your full name.',
    email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) || 'Enter a valid email address.',
    message: (v) => v.trim().length >= 10 || 'Message must be at least 10 characters.'
  };

  // Escape any HTML the user types before it ever touches the DOM.
  // This is a template that renders no user input back to the page,
  // but the helper is here so future edits stay safe by default.
  function sanitize(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function validateField(field) {
    const wrap = field.closest('.field');
    const errEl = wrap.querySelector('.err');
    const rule = validators[field.name];
    if (!rule) return true;

    const result = rule(field.value);
    if (result === true) {
      wrap.classList.remove('invalid');
      errEl.textContent = '';
      return true;
    } else {
      wrap.classList.add('invalid');
      errEl.textContent = result;
      return false;
    }
  }

  form.querySelectorAll('input, textarea').forEach(field => {
    field.addEventListener('blur', () => validateField(field));
    field.addEventListener('input', () => {
      if (field.closest('.field').classList.contains('invalid')) {
        validateField(field);
      }
    });
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const fields = form.querySelectorAll('input, textarea');
    let allValid = true;
    fields.forEach(f => { if (!validateField(f)) allValid = false; });

    if (!allValid) {
      status.className = 'form-status show';
      status.style.color = 'var(--danger)';
      status.textContent = 'Please fix the errors above before sending.';
      return;
    }

    // No backend wired up yet — this just confirms the payload is clean.
    const payload = {
      name: sanitize(form.name.value.trim()),
      email: sanitize(form.email.value.trim()),
      message: sanitize(form.message.value.trim())
    };
    console.log('Validated contact payload (not sent — no backend configured):', payload);

    status.className = 'form-status show ok';
    status.textContent = 'Message validated ✓ — connect a form backend (e.g. Netlify Forms or Formspree) to actually send this.';
    form.reset();
  });
}
